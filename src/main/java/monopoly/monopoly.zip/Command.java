package monopoly;
public interface Command{
    Game g = new Game();
    public void excute();
}
