package monopoly;
import java.util.concurrent.ThreadLocalRandom;
import java.util.*;
import java.io.*;
public class Game{
    int location;
    int dice1;
    int dice2;
    int round = 1;
    int numOfPlayer = 0;
    int currentPlayer = 0;
    ArrayList<Map> map = new ArrayList<Map>();
    ArrayList<Integer> save = new ArrayList<Integer>();
    ArrayList<Player> players= new ArrayList<Player>();
    GoToJail jail = new GoToJail();
    PrintGameBoard pgb;
    Scanner sc= new Scanner(System.in);
    public void newGame(){
        boolean checker = false;
        while(!checker){
            System.out.println("How many players?");
            numOfPlayer = sc.nextInt();
            if(numOfPlayer>=2&&numOfPlayer<=6){
                checker = true;
            }
        }               
        map.add(new Go());
        map.add(new Central());
        map.add(new WanChai());
        map.add(new Tax());
        map.add(new Stanley());
        map.add(new Jail());
        map.add(new ShekO());
        map.add(new MongKok());
        map.add(new Chance(9));
        map.add(new TsingYi());
        map.add(new FreePark());
        map.add(new ShaTin());
        map.add(new Chance(13));
        map.add(new TuenMun());
        map.add(new TaiPo());
        map.add(jail);
        map.add(new SaiKung());
        map.add(new YuenLong());
        map.add(new Chance(19));
        map.add(new TaiO());
        for(int x=0;x<numOfPlayer;x++){
            System.out.println("Please input player name:   ");
            String name = sc.next();
            players.add(new Player(name,1500)); 
        }
        pgb = new PrintGameBoard();
        pgb.printProcess(map,players);
        System.out.println("Now is " + players.get(0).getName() + " turn");
        System.out.println("Round " + round);
    }

    public ArrayList<Player> getPlayer(){
        return players;
    }

    public ArrayList<Map> getMap(){
        return map;
    }

    public void playGame(){
        boolean inJail = false;
        String sentence ="";
        dice1 =0;
        dice2 =0;
        Player player = players.get(currentPlayer);
        if(jail.checkPrisoner(player.getName())){
            int time = jail.getTime(player.getName());
            inJail=true;
            dice1 = ThreadLocalRandom.current().nextInt(1, 4 + 1);
            dice2 = ThreadLocalRandom.current().nextInt(1, 4 + 1);
            if(time>1){
                System.out.println("Pay 150 to leave? Yes-y   NO-n");
                String choice = sc.next();
                if(choice.equals("y")){
                    inJail=false;
                    jail.removePrisoner(player.getName());
                    player.setMoney(player.getMoney()-150);
                }
            }   
            if(dice1==dice2){
                inJail=false;
                sentence = "You get out of the jail!";
                jail.removePrisoner(player.getName());
            }
            else if(time==3){
                inJail=false;
                jail.removePrisoner(player.getName());
                player.setMoney(player.getMoney()-150);
            }
            if(inJail){
                time+=1;
                jail.addTime(player.getName(),time);
                pgb.printProcess(map,players);
                System.out.println("You roll " + Integer.toString(dice1) + " and " + Integer.toString(dice2));
                System.out.println("you can not make it");
            }
            location = player.getLocation() + dice1 + dice2;
        }else{
            dice1 = ThreadLocalRandom.current().nextInt(2, 8 + 1);
            location = player.getLocation() + dice1;
            if(location > 20){
                location -= 20;
                player.setMoney(player.getMoney()+1500);
            }
        }
        if(!inJail){
            player.setLocation(location);
            pgb.printProcess(map,players);
            System.out.println("You roll " + Integer.toString(dice1) + " and " + Integer.toString(dice2));
            System.out.println(sentence);
            System.out.println();
            for(int x=0;x<map.size();x++){
                if(location == map.get(x).getLocation()){
                    switch(map.get(x).getType()){
                        case "property":
                        Property p = (Property)map.get(x);
                        String owner = p.getOwner();
                        if(owner!=null){
                            if(!owner.equals(player.getName())){
                                if(checkEnough(player.getMoney(),p.getRent())){
                                    player.setMoney(player.getMoney()-p.getRent());
                                    for(int i=0;i<players.size();i++){
                                        if(p.getOwner().equals(players.get(i).getName())){
                                            Player pOwner = players.get(i);
                                            pOwner.setMoney(pOwner.getMoney()+p.getRent());
                                        }
                                    }
                                    pgb.printProcess(map,players);
                                    System.out.println();
                                    System.out.println("You paid $" + p.getRent() + " to " + p.getOwner());
                                }else{
                                    System.out.println("You Lose");
                                }

                            }
                        }else{
                            System.out.println("Buy property? Yes-y No-n");
                            String choice = sc.next();
                            if(choice.equals("y")){
                                if(checkEnough(player.getMoney(),p.getPrice())){
                                    p.setOwner(player.getName());
                                    player.setMoney(player.getMoney()-p.getPrice());
                                    pgb.printProcess(map,players);
                                    System.out.println();
                                    System.out.println(player.getName()+ " buy " + p.getName());
                                }else{
                                    System.out.println("You do not have enough money!");
                                }
                            }
                        }
                        break;
                        case "Chance":
                        Chance c = (Chance)map.get(x);
                        int luckymoney = c.getChance();
                        if(checkEnough(player.getMoney(),luckymoney)){
                            player.setMoney(player.getMoney()+luckymoney);
                            System.out.println(player.getName()+ " get $ " + luckymoney);
                        }else{
                            System.out.println("You Lose");
                            players.remove(currentPlayer);
                        }

                        break;
                        case "Tax":
                        Tax t = (Tax)map.get(x);
                        int tax = t.payTax(player.getMoney());
                        player.setMoney(player.getMoney()-tax);
                        System.out.println("You have deducted $" + tax);
                        break;
                        case "Go to Jail":
                        jail.setPrisoner(player.getName());
                        player.setLocation(6);
                        pgb.printProcess(map,players);
                        System.out.println("You Go to Jail");
                        break;
                        default:
                        System.out.println("nothing happen");
                    }
                }
            }
        }
        if(currentPlayer+1>players.size()-1){
            currentPlayer = 0;
            round++;
        }else{
            currentPlayer++;
        }
        System.out.println();
        System.out.println();
        if(round<=100){
            System.out.println("Now is " + players.get(currentPlayer).getName() + " turn");
            System.out.println("Your location is: " + players.get(currentPlayer).getLocation());
            System.out.println();
            System.out.println("Round " + round);
        }else{
            //print finish
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println();
            System.out.println("result");
            viewStatus(false);
            System.out.println();
            System.out.println();
            System.out.println("finish");
            System.out.println();
            System.out.println();
        }

    }

    public boolean checkEnough(int pMoney, int number){
        boolean enough = true;
        if(pMoney-number<0){
            enough = false;
        }
        return enough;
    }

    public void viewStatus(boolean personal){
        int total;
        int first;
        if(personal){
            first = currentPlayer;
            total = currentPlayer+1;
        }else{
            first = 0;
            total = players.size();
        }
        for(int x=first;x<total;x++){
            System.out.println(players.get(x).getName());
            System.out.println(players.get(x).getLocation());
            System.out.println(players.get(x).getMoney());
            for(int y=0;y<map.size();y++){
                if(map.get(y).getType().equals("Property")){
                    Property p = (Property)map.get(y);
                    if(p.getOwner().equals(players.get(x).getName())){
                        System.out.println(p.getName());
                    }
                }
            }
            System.out.println();
            if(jail.checkPrisoner(players.get(x).getName())){
                System.out.println("in Jail; Ronund " + jail.getTime(players.get(x).getName()));
            }
        }
    }

    public void saveGame(){
        FileOutputStream fileOut;
        ObjectOutputStream out;
        try
        {
            fileOut = new FileOutputStream("C:/Users/Public/Documents/SE/map"+ round +".ser");
            out = new ObjectOutputStream(fileOut);
            out.writeObject(map);
            fileOut = new FileOutputStream("C:/Users/Public/Documents/SE/players"+ round +".ser");
            out = new ObjectOutputStream(fileOut);
            out.writeObject(players);
            fileOut = new FileOutputStream("C:/Users/Public/Documents/SE/jail"+ round +".ser");
            out = new ObjectOutputStream(fileOut);
            out.writeObject(jail);
            fileOut = new FileOutputStream("C:/Users/Public/Documents/SE/currentPlayer0000"+ round +".ser");
            out = new ObjectOutputStream(fileOut);
            out.writeObject(currentPlayer);
            fileOut = new FileOutputStream("C:/Users/Public/Documents/SE/round00000000"+ round +".ser");
            out = new ObjectOutputStream(fileOut);
            out.writeObject(round);
            out.close();
            fileOut.close();
            System.out.println("Serialized data is saved");
        }catch(IOException i)
        {
            i.printStackTrace();
        }
        save.add(round);
    }

    public void loadGame(){
        System.out.print("Please select which round you want to load: ");
        for (int i=0;i<save.size();i++) {
            System.out.print(save.get(i)+ "; ");
        }
        int savedRound = sc.nextInt();
        try
        {
            FileInputStream fileIn;
            ObjectInputStream in;
            fileIn = new FileInputStream("C:/Users/Public/Documents/SE/map"+ savedRound +".ser");
            in = new ObjectInputStream(fileIn);
            map = (ArrayList<Map>) in.readObject();
            fileIn = new FileInputStream("C:/Users/Public/Documents/SE/players"+ savedRound +".ser");
            in = new ObjectInputStream(fileIn);
            players = (ArrayList<Player>) in.readObject();
            fileIn = new FileInputStream("C:/Users/Public/Documents/SE/jail"+ savedRound +".ser");
            in = new ObjectInputStream(fileIn);
            jail = (GoToJail) in.readObject();
            fileIn = new FileInputStream("C:/Users/Public/Documents/SE/currentPlayer0000"+ savedRound +".ser");
            in = new ObjectInputStream(fileIn);
            currentPlayer = (Integer)in.readObject();
            fileIn = new FileInputStream("C:/Users/Public/Documents/SE/round00000000"+ savedRound +".ser");
            in = new ObjectInputStream(fileIn);
            round = (Integer)in.readObject();
            in.close();
            fileIn.close();
        }catch(IOException i)
        {
            i.printStackTrace();
            return;
        }catch(ClassNotFoundException c)
        {
            c.printStackTrace();
            return;
        }
        pgb.printProcess(map,players);
        System.out.println("Now is " + players.get(currentPlayer).getName() + " turn");
        System.out.println("Your location is: " + players.get(currentPlayer).getLocation());
        System.out.println();
        System.out.println("Round " + round);
    }

}