package monopoly;
public class RollDice implements Command {
    public void excute(){
        g.playGame();
    }
    
}
