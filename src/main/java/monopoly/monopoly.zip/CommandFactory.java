package monopoly;
public abstract class CommandFactory {
    public abstract Command createCommand();
}