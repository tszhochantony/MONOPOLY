package monopoly;
public class Initialize implements Command {
    public void excute(){    
        g.newGame(); 
    }
}
