package monopoly;
public class LoadGame implements Command {
    public void excute(){
        g.loadGame();
    }
}
